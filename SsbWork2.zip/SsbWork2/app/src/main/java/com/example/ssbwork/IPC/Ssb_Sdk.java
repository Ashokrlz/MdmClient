package com.example.ssbwork.IPC;

import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.ServiceConnection;
import android.os.IBinder;

public class Ssb_Sdk implements ServiceConnection {

    private String _package = "";
    private Context _context;
    private App_State _appState = new App_State();

    private BroadcastReceiver _receiverPackage;
    private BroadcastReceiver _receiverMessageState;
    private static final String _patrolActivityClass = "com.example.moipatrol.Activities.MainActivity";

    Ssb_Sdk() {
    }

    @SuppressLint({"InlinedApi"})
    void onCreate(String packageName, Context context) {
        if (context != null) {
            this._context = context.getApplicationContext();
            this._appState._Available = this.isAppAvailable();
        }
    }

    @Override
    public void onServiceConnected(ComponentName componentName, IBinder iBinder) {

    }

    @Override
    public void onServiceDisconnected(ComponentName componentName) {

    }

    @Override
    public void onBindingDied(ComponentName name) {

    }

    @Override
    public void onNullBinding(ComponentName name) {

    }


    private boolean isAppAvailable() {
        Context context = this._context;
        if (context == null) {
            return false;
        } else {
            try {
                return null != context.getPackageManager().getLaunchIntentForPackage(this._package);
            } catch (Throwable var3) {
                return false;
            }
        }
    }
}
