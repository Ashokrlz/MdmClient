package com.example.ssbwork;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.widget.TextView;

import com.example.ssbwork.IPC.SsbBroadcastReceiver;

public class MainActivity extends AppCompatActivity {

    private TextView connectionStatus;
    private Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        connectionStatus = findViewById(R.id.connectionStatus);

        if (android.os.Build.VERSION.SDK_INT > 9) {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
        }

        context = getApplicationContext();

        Intent serviceIntent = new Intent(getApplicationContext(), SsbService.class);
        getApplicationContext().startService(serviceIntent);

        if(!AppUtility.isAppRunning(context, "com.example.moipatrol")) {
            Intent LaunchIntent = context.getPackageManager().getLaunchIntentForPackage("com.example.moipatrol");
            try {
                context.startActivity(LaunchIntent);
            } catch (Throwable var4) {
            }
        }

        SsbBroadcastReceiver MyReceiver = new SsbBroadcastReceiver();
        IntentFilter intentFilter = new IntentFilter("com.ssbwork.COMMAND");
        if(intentFilter != null)
        {
            registerReceiver(MyReceiver, intentFilter);
        }
    }
}
