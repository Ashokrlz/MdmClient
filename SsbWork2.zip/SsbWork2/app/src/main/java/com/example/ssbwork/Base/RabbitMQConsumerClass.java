package com.example.ssbwork.Base;

import android.content.Context;
import android.os.Handler;
import android.util.Log;
import android.widget.Toast;

import com.rabbitmq.client.AMQP;
import com.rabbitmq.client.DefaultConsumer;
import com.rabbitmq.client.Envelope;

import java.io.IOException;

public class RabbitMQConsumerClass extends RabbitMQAuthClass {
    /**
     * @param server       The server address
     * @param port         The server port
     * @param ctx          Application Context
     * @param exchange     The named exchange
     * @param exchangeType The exchange type name
     */
    public RabbitMQConsumerClass(String server, int port, Context ctx, String exchange, String exchangeType) {
        super(server, port, ctx, exchange, exchangeType);
    }

    private byte[] mLastMessage;
    private String mReceivedFrom = "";
    private String mMainQueue = "MainQueue";


    // An interface to be implemented by an object that is interested in messages(listener)
    public interface OnReceiveMessageHandler{
        public void onReceiveMessage(byte[] message, String receivedFrom);
    };

    //A reference to the listener, we can only have one at a time(for now)
    private OnReceiveMessageHandler mOnReceiveMessageHandler;

    /**
     *
     * Set the callback for received messages
     * @param handler The callback
     */
    public void setOnReceiveMessageHandler(OnReceiveMessageHandler handler){
        mOnReceiveMessageHandler = handler;
    };

    private Handler mMessageHandler = new Handler();

    final Runnable mReturnMessage = new Runnable() {
        public void run() {
            mOnReceiveMessageHandler.onReceiveMessage(mLastMessage, mReceivedFrom);
        }
    };


    /**
     * Create Exchange and then start consuming. A binding needs to be added before any messages will be delivered
     */

    @Override
    public boolean connectToRabbitMQ()
    {
        if(super.connectToRabbitMQ())
        {
            if(!consumeQueue(mMainQueue)){
                return false;
            }

            Running = true;

            return true;
        }
        return false;
    }



    public boolean consumeQueue(String queueName){

        try{
            DefaultConsumer MySubscription = new DefaultConsumer(mChannel){
                @Override
                public void handleDelivery(String consumerTag, Envelope envelope,
                                           AMQP.BasicProperties properties, byte[] body) throws IOException {
                    String routingKey = envelope.getRoutingKey();
                    String contentType = properties.getContentType();
                    long deliveryTag = envelope.getDeliveryTag();
                    Log.i("SsbService", "ReceivedMsg");
                    mLastMessage = body;
                    mReceivedFrom = routingKey;
//                  mChannel.basicAck(deliveryTag, false);
                    mMessageHandler.post(mReturnMessage);
                }
            };
            mChannel.queueDeclare(queueName, true, false, false, null);
            mChannel.basicConsume(queueName, false, MySubscription);

            if (MyExchangeType == "fanout")
                AddBinding("", queueName); //fanout has default binding

        } catch (Exception e){
            e.printStackTrace();
            return false;
        }
        return true;
    }


    public void publishToExchange(String message){
        try {
            mChannel.basicPublish(mExchange, "", null, message.getBytes());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }



    /**
     * Add a binding between this consumers Queue and the Exchange with routingKey
     * @param routingKey the binding key eg GOOG
     */
    public void AddBinding(String routingKey, String queue)
    {
        try {
            mChannel.queueBind(queue, mExchange, routingKey);
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }


    /**
     * Remove binding between this consumers Queue and the Exchange with routingKey
     * @param routingKey the binding key eg GOOG
     */
    public void RemoveBinding(String routingKey, String queue)
    {
        try {
            mChannel.queueUnbind(queue, mExchange, routingKey);
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }


    public void dispose(){
        Running = false;
    }

}
