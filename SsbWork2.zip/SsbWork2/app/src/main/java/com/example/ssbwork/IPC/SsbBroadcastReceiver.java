package com.example.ssbwork.IPC;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import com.example.ssbwork.SsbService;

public class SsbBroadcastReceiver extends android.content.BroadcastReceiver {


    private static String TAG = "SSBWork Broadcast Receiver";
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent != null) {
            String message = intent.getExtras().getString("COMMAND");
            Log.i("From SSB", message);
            Intent i = new Intent(context, SsbService.class);
            i.putExtra("PublishMessage", message);

            SsbService service = new SsbService();
            service.publish(message);
        }
    }
}
