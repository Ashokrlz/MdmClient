package com.example.ssbwork;

import android.app.Service;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.IBinder;
import android.util.Log;
import android.widget.Toast;


import com.example.ssbwork.Base.RabbitMQConsumerClass;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;

import java.io.UnsupportedEncodingException;

import static com.example.ssbwork.AppConstant.EXCHANGE_TYPE_FANOUT;
import static com.example.ssbwork.AppConstant.SERVER_ADDR;
import static com.example.ssbwork.AppConstant.SERVER_PORT;

public class SsbService extends Service {

    private static String TAG = "SsbService";
    private static Connection ServerConnection;
    private static Channel channel;
    private static RabbitMQConsumerClass mConsumer;
    private String text = "";


    public SsbService() {
    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.i("Publishing to Queue", "Enters On Start");
        if(mConsumer.connectToRabbitMQ()) {
            if (intent.getExtras() != null) {
                String message = intent.getExtras().getString("PublishMessage");
                mConsumer.publishToExchange(message);
                Log.i("Publishing to Queue", message);
            }
        }
        return START_NOT_STICKY;
    }

    @Override
    public void onCreate() {
        Log.i(TAG, "Service Started");
        connectToRabbit();
    }


    @Override
    public void onDestroy() {
        /* IF YOU WANT THIS SERVICE KILLED WITH THE APP THEN UNCOMMENT THE FOLLOWING LINE */
        Log.i(TAG, "Service Destroyed");
    }


    public void publish(String msg){
        mConsumer.publishToExchange(msg);
    }


    public void connectToRabbit(){
        mConsumer = new RabbitMQConsumerClass(SERVER_ADDR,
                SERVER_PORT,
                getApplicationContext(),
                "exchangeTest",
                EXCHANGE_TYPE_FANOUT
                );

        boolean isConnected = mConsumer.connectToRabbitMQ();

        if(isConnected)


        mConsumer.setOnReceiveMessageHandler(new RabbitMQConsumerClass.OnReceiveMessageHandler(){
            public void onReceiveMessage(byte[] message, String receivedFrom){
                try {
                    text = "From- " + receivedFrom + " " + new String(message, "UTF8");
                    Log.i(TAG, text);
                    final Intent i= new Intent();
                    i.putExtra("MessageReceived", text);
                    i.setAction("com.moi.patrol.COMMAND");
                    i.addFlags(Intent.FLAG_INCLUDE_STOPPED_PACKAGES);
                    getApplicationContext().sendBroadcast(i);
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                }
            }
        });

        }


    public void sendBroadcast(String command){
        String filter = "ptt_fragment";
        Intent intent = new Intent(filter);
        intent.putExtra("command", command);
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }
    }
