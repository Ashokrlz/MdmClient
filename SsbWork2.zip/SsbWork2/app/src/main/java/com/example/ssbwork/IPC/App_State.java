package com.example.ssbwork.IPC;

public class App_State {
    boolean _Available;
    boolean _Connecting;
    boolean _Connected;
    boolean _Error;
    boolean _Reconnecting;
    boolean _WaitingForNetwork;

    String _UserName;
    String _StatusMessage;
    Error  _LastError;

    public App_State() {
        this._LastError = Error.NONE;
    }


    public void reset() {
         _Connecting = false;
         _Connected = false;
         _Error = false;
         _Reconnecting = false;
         _WaitingForNetwork = false;
         _Available = false;
    }

    public boolean is_Connecting() {
        return _Connecting;
    }

    public void set_Connecting(boolean _Connecting) {
        this._Connecting = _Connecting;
    }

    public boolean is_Connected() {
        return _Connected;
    }

    public void set_Connected(boolean _Connected) {
        this._Connected = _Connected;
    }

    public boolean is_Error() {
        return _Error;
    }

    public void set_Error(boolean _Error) {
        this._Error = _Error;
    }

    public boolean is_Reconnecting() {
        return _Reconnecting;
    }

    public void set_Reconnecting(boolean _Reconnecting) {
        this._Reconnecting = _Reconnecting;
    }

    public boolean is_WaitingForNetwork() {
        return _WaitingForNetwork;
    }

    public void set_WaitingForNetwork(boolean _WaitingForNetwork) {
        this._WaitingForNetwork = _WaitingForNetwork;
    }

    public String get_UserName() {
        return _UserName;
    }

    public void set_UserName(String _UserName) {
        this._UserName = _UserName;
    }

    public String get_StatusMessage() {
        return _StatusMessage;
    }

    public void set_StatusMessage(String _StatusMessage) {
        this._StatusMessage = _StatusMessage;
    }

    public Error get_LastError() {
        return _LastError;
    }

    public void set_LastError(Error _LastError) {
        this._LastError = _LastError;
    }

    public boolean is_Available() {
        return _Available;
    }

    public void set_Available(boolean _Available) {
        this._Available = _Available;
    }
}
