package com.example.ssbwork.IPC;

public enum Error {
    NONE,
    UNKNOWN,
    INVALID_CREDENTIALS,
    NETWORK_SUSPENDED,
    SERVER_SECURE_CONNECT_FAILED,
    NO_INTERNET_CONNECTION,
    INTERNET_CONNECTION_RESTRICTED,
    DEVICE_ID_MISMATCH;

    private Error() {
    }
}
