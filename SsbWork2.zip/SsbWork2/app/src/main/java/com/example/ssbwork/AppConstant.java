package com.example.ssbwork;

public class AppConstant {

    public static String SERVER_ADDR = "bunny.khalefa.io";
    public static int SERVER_PORT = 5671;

    public static String TLS_VERSION = "TLSv1.2";
    public static String CLIENT_CERTPASSWORD = "bunnies";
    public static String SERVER_CERTPASSWORD = "Abc123";

    public static String DEVICE_IMEI = "IMEI";
    public static String EXCHANGE_TYPE_FANOUT = "fanout";
}
