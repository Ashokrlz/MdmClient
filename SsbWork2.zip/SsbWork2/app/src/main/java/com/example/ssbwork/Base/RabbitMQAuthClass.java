package com.example.ssbwork.Base;

import android.content.Context;

import com.example.ssbwork.R;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.DefaultSaslConfig;

import java.io.IOException;
import java.security.KeyStore;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManagerFactory;

import static com.example.ssbwork.AppConstant.CLIENT_CERTPASSWORD;
import static com.example.ssbwork.AppConstant.SERVER_CERTPASSWORD;
import static com.example.ssbwork.AppConstant.TLS_VERSION;

public class RabbitMQAuthClass {
    public String mServer;
    public int mPort;
    public String mExchange;

    public Context mContext;
    public Channel mChannel = null;
    protected Connection mConnection;

    protected boolean Running ;

    protected  String MyExchangeType;

    /**
     * @param server       The server address
     * @param port         The server port
     * @param ctx          Application Context
     * @param exchange     The named exchange
     * @param exchangeType The exchange type name
     */

    public RabbitMQAuthClass(String server, int port, Context ctx, String exchange, String exchangeType)
    {
        mServer = server;
        mPort = port;
        mExchange = exchange;
        MyExchangeType = exchangeType;
        mContext = ctx;
    }


    public void disposeRabbitMQConnection()
    {
        Running = false;

        try {
            if (mConnection!=null)
                mConnection.close();
            if (mChannel != null)
                mChannel.abort();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }


    /**
     * Connect to the broker and create the exchange
     * @return success
     */
    public boolean connectToRabbitMQ()
    {
        if(mChannel!= null && mChannel.isOpen() )//already declared
        {
            return true;
        }
                try {
                    char[] keyPassphrase = CLIENT_CERTPASSWORD.toCharArray();
                    KeyStore ks = null;
                    ks = KeyStore.getInstance("PKCS12");
                    ks.load(mContext.getResources().openRawResource(R.raw.client_key),
                            keyPassphrase);

                    KeyManagerFactory kmf = null;
                    kmf = KeyManagerFactory.getInstance("X509");
                    kmf.init(ks, keyPassphrase);

                    char[] trustPassphrase = SERVER_CERTPASSWORD.toCharArray();
                    KeyStore tks = null;
                    tks = KeyStore.getInstance("BKS");
                    tks.load(mContext.getResources().openRawResource(R.raw.newbksstore),
                            trustPassphrase);

                    TrustManagerFactory tmf = null;
                    tmf = TrustManagerFactory.getInstance("X509");
                    tmf.init(tks);

                    SSLContext c = null;
                    c = SSLContext.getInstance(TLS_VERSION);
                    c.init(kmf.getKeyManagers(), tmf.getTrustManagers(), null);

                    ConnectionFactory connectionFactory = new ConnectionFactory();
                    connectionFactory.setHost(mServer);
                    connectionFactory.setPort(mPort);
                    connectionFactory.useSslProtocol(c);
                    connectionFactory.setSaslConfig(DefaultSaslConfig.EXTERNAL);
                    connectionFactory.enableHostnameVerification();
                    connectionFactory.setAutomaticRecoveryEnabled(true);
                    connectionFactory.setNetworkRecoveryInterval(5000);
                    connectionFactory.setConnectionTimeout(20000);

                    mConnection = connectionFactory.newConnection();
                    mChannel = mConnection.createChannel();
                    mChannel.exchangeDeclare(mExchange, MyExchangeType, true);
                    return true;

                } catch (Exception e) {
                    e.printStackTrace();
                    return false;
                }
            }
}
